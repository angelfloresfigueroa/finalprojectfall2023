from tkinter import *


root = Tk()

root.geometry("850x900")
bg = PhotoImage(file="taco1.png")

root.title("Taco Ordering System ")

lbl = Label(root, text="Welcome to Angels Tacos", font=("Futura Black", 30))
lbl.grid(row=0, column=0)
lbl.place(x=180,y=0)
lbl_0 = Label(root, text="Order whatever your hungry for!!", font=("Futura Black", 20))
lbl_0.grid(row=0, column=0)
lbl_0.place(x=225,y=60)
lbl_1 = Label(root, text="Select Your Type of Tacos", font=("Futura Black", 15))
lbl_1.grid(column=0, row=0)
lbl_1.place(x=300,y=100)
lbl_2 = Label(root, text="Select Your Drink", font=("Futura Black", 15))
lbl_2.grid(column=0, row=0)
lbl_2.place(x=320,y=350)


btn1 = Button(root, text="Click Me ")
btn1.grid(column=1, row=0)
btn1.place(x=200,y=310)
btn2 = Button(root, text="Click Me")
btn2.grid(column=1, row=0)
btn2.place(x=370,y=310)
btn3 = Button(root, text="Click Me")
btn3.grid(column=1, row=0)
btn3.place(x=550,y=310)

btn4 = Button(root, text="Click Me ")
btn4.grid(column=1, row=0)
btn4.place(x=200,y=310)
btn5 = Button(root, text="Click Me")
btn5.grid(column=1, row=0)
btn5.place(x=370,y=310)
btn6 = Button(root, text="Click Me")
btn6.grid(column=1, row=0)
btn6.place(x=550,y=310)

root.mainloop()